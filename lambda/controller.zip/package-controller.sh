# keep this file inside the lambda dir
# give excution rights to this file
# run to repack controller.zip
rm controller.zip
zip -r controller.zip *