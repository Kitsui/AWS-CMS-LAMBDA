"""
# authentication.py
# Created: 6/07/2016
# Author: Miguel Saavedra
"""
import boto3
import botocore
from boto3.dynamodb.conditions import Key, Attr

class Response(object):

	def __init__(self, auth_data):
		self.auth_data = auth_data

	def authenticate(self):
		try:
			dynamodb = boto3.resource('dynamodb')
			table = dynamodb.Table('Token')
			blogData = table.query(KeyConditionExpression=
				Key('TokenString').eq(self.auth_data))
		except botocore.exceptions.ClientError as e:
			print e.response['Error']['Code']
			return False
		return True
