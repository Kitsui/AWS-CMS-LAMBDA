#!/usr/bin/python2.7

def translate_python(json_var) {
	
}