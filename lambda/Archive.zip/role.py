"""
# role.py
# Author: Adam Campbell
# Date: 05/08/2016
"""

import boto3
import botocore

class Role(object):

    def __init__(self, event, context):
        self.event = event
        self.context = context

    def create_role(self):
        pass

    # Removes role from Roles if exists
    def remove_role(self):
        
        role_id = self.event["role_id"];

        try:
            dynamodb = boto3.client("dynamodb")
            # Attempt to delete role
            dynamodb.delete_item(
                TableName="Role",
                Key={
                    "RoleID": {
                        "S": role_id
                    }
                }
            )

            # Check that role has been deleted
            role_data = dynamodb.query(
                TableName="Role",
                KeyConditionExpression=Key("RoleID").eq(role_id)
            )

            # Role still exists
            if role_data["Count"] > 0:
                response = Response("Error", None)
                response.errorMessage = "Unable to delete role"
            # Role removed successfully
            else:
                response = Response("Success", None)
        except botocore.exceptions.ClientError as e:
            # DynamoDB exception occured
            error_code = e.response["Error"]["Code"]
            response = Response("Error", None)
            response.errorMessage = "Unable to delete role: %s" % error_code 
                
        return response.to_JSON()

    